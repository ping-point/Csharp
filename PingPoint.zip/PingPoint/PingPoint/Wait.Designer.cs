﻿namespace PingPoint
{
    partial class Wait
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_change = new System.Windows.Forms.Label();
            this.label_next_set = new System.Windows.Forms.Label();
            this.label_info_win = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_change
            // 
            this.label_change.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_change.ForeColor = System.Drawing.Color.Orange;
            this.label_change.Location = new System.Drawing.Point(-1, 73);
            this.label_change.Name = "label_change";
            this.label_change.Size = new System.Drawing.Size(290, 80);
            this.label_change.TabIndex = 0;
            this.label_change.Text = "Dokonaj zmian";
            this.label_change.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_change.Click += new System.EventHandler(this.label_change_Click);
            // 
            // label_next_set
            // 
            this.label_next_set.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_next_set.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label_next_set.Location = new System.Drawing.Point(295, 73);
            this.label_next_set.Name = "label_next_set";
            this.label_next_set.Size = new System.Drawing.Size(290, 80);
            this.label_next_set.TabIndex = 1;
            this.label_next_set.Text = "Przejdź do następnego setu";
            this.label_next_set.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_next_set.Click += new System.EventHandler(this.label_next_set_Click);
            // 
            // label_info_win
            // 
            this.label_info_win.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_info_win.ForeColor = System.Drawing.Color.OrangeRed;
            this.label_info_win.Location = new System.Drawing.Point(-10, 0);
            this.label_info_win.Name = "label_info_win";
            this.label_info_win.Size = new System.Drawing.Size(600, 80);
            this.label_info_win.TabIndex = 2;
            this.label_info_win.Text = "Set wygrywa: Radohan";
            this.label_info_win.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Wait
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 162);
            this.ControlBox = false;
            this.Controls.Add(this.label_next_set);
            this.Controls.Add(this.label_info_win);
            this.Controls.Add(this.label_change);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Wait";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_change;
        private System.Windows.Forms.Label label_next_set;
        private System.Windows.Forms.Label label_info_win;
    }
}