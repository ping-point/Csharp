﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PingPoint
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (PingPoint_main form2 = new PingPoint_main())
            {
                if (form2.ShowDialog() == DialogResult.OK)
                {
                    /*
                    textBox_login.Text = form2.Login;
                    textBox_password.Text = form2.Password;
                    */
                }
            }
        }
    }
}
